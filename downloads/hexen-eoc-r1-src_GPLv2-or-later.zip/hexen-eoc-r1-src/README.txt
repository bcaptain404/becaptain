# Description
This package is a re-release of the Hexen: Edge of Chaos source patch file (originally released Feb 22, 2011) for the purpose of relicensing it to the GNU GPLv2. This patch file will convert a fresh Doom3 SDK v1.3.1 into the complete sources used to compile the game. It does not include game assets.

# Requirements
- Doom3 SDK version 1.3.1
- the GNU patch program (if on Windows: https://gnuwin32.sourceforge.net/packages/patch.htm)

# Instructions
* Download the Doom3 SDK 1.3.1 and install it.
* If on Windows, download the `patch` program.
* Place the hexen.patch file inside your extracted Doom3 SDK directory alongside of (not inside of) the 'src' directory.
* Open a terminal or command prompt, `cd` into the directory where you put the patch file in the previous step, and apply the patch via `patch -up0 -i hexen.patch`. If on Windows, you'll probably have to supply the full path to the `patch` program that you downloaded (or you can just stick it right in the same directory).
* If anything goes wrong, it's likely because you either put the patch file in the wrong directory, or have the wrong SDK files (A different version, or possibly a modified SDK, etc).
* If everything went well, your SDK is now the sources of the first release of Hexen: Edge of Chaos. Enjoy!

